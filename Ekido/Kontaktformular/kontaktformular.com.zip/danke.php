<!DOCTYPE html>
<html lang="de-DE">
	<head>
		<meta charset="utf-8">
		<meta name="language" content="de"/>
		<meta name="description" content="kontaktformular.com"/>
		<meta name="revisit" content="After 7 days"/>
		<meta name="robots" content="INDEX,FOLLOW"/>
		<title>kontaktformular.com</title>
	
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<style type="text/css">
body{font-family:Verdana,Arial,Helvetica,sans-serif;font-size:14px;color:#000000;background-color: #FFFFFF;}
a:link, a:visited, a:active{color:#000000;text-decoration:none;}
a:hover{text-decoration: underline;}
</style>

	</head>



<body>

<div>

 
    
	<p>Vielen Dank. Ihre Nachricht wurde erfolgreich &uuml;bermittelt.</p>		
 <p><br /><br />
 <a href="https://www.kontaktformular.com" onclick="window.open(this.href); return false;" title="kontaktformular.com" style="font-size:12px; "><!-- Dieser Copyrighthinweis darf NICHT entfernt werden. -->&copy; by kontaktformular.com</a></p>

</div>

</body>
</html>